#'
#' @docType data
#' @title emln68_temporal_environment_baeta_2011
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type  | mangal_code | ecological_network_type | state_nodes |
#' |:----------:|:------------------------:|:-----------:|:-----------------------:|:-----------:|
#' |     68     | Temporal   , Environment |     73      |        Food-Web         |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source mangal
#' @source https://mangal.io/doc/api/
#' @md
#' @keywords internal
'emln68_temporal_environment_baeta_2011'
