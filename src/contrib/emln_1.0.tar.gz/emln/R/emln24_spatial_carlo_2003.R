#'
#' @docType data
#' @title emln24_spatial_carlo_2003
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------------------:|:-----------:|
#' |     24     |         Spatial         |     Seed-Dispersal      |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source Web_of_Life
#' @source http://www.web-of-life.es/map.php
#' @md
#' @keywords internal
'emln24_spatial_carlo_2003'
