#'
#' @docType data
#' @title emln12_environment_fryer_1959
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | mangal_code | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------:|:-----------------------:|:-----------:|
#' |     12     |       Environment       |     94      |        Food-Web         |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source mangal
#' @source https://mangal.io/doc/api/
#' @md
#' @keywords internal
'emln12_environment_fryer_1959'
