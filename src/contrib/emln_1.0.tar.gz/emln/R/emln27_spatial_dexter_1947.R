#'
#' @docType data
#' @title emln27_spatial_dexter_1947
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | mangal_code | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------:|:-----------------------:|:-----------:|
#' |     27     |         Spatial         |     54      |        Food-Web         |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source mangal
#' @source https://mangal.io/doc/api/
#' @md
#' @keywords internal
'emln27_spatial_dexter_1947'
