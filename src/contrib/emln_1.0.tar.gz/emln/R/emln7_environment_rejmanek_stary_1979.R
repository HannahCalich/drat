#'
#' @docType data
#' @title emln7_environment_rejmanek_stary_1979
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | mangal_code | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------:|:-----------------------:|:-----------:|
#' |     7      |       Environment       |     112     |      Host-Parasite      |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source mangal
#' @source https://mangal.io/doc/api/
#' @md
#' @keywords internal
'emln7_environment_rejmanek_stary_1979'
