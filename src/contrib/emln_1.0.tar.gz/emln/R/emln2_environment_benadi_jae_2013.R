#'
#' @docType data
#' @title emln2_environment_benadi_jae_2013
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------------------:|:-----------:|
#' |     2      |       Environment       |       Pollination       |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source Dryad
#' @source https://datadryad.org/stash/dataset/doi:10.5061/dryad.8mn44
#' @md
#' @keywords internal
'emln2_environment_benadi_jae_2013'
