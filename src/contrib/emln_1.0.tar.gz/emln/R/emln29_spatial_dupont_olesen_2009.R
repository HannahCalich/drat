#'
#' @docType data
#' @title emln29_spatial_dupont_olesen_2009
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------------------:|:-----------:|
#' |     29     |         Spatial         |       Pollination       |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source Web_of_Life
#' @source http://www.web-of-life.es/map.php
#' @md
#' @keywords internal
'emln29_spatial_dupont_olesen_2009'
