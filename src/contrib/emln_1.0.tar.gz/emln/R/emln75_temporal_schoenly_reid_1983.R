#'
#' @docType data
#' @title emln75_temporal_schoenly_reid_1983
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | mangal_code | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------:|:-----------------------:|:-----------:|
#' |     75     |        Temporal         |     149     |        Food-Web         |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source mangal
#' @source https://mangal.io/doc/api/
#' @md
#' @keywords internal
'emln75_temporal_schoenly_reid_1983'
