#'
#' @docType data
#' @title emln57_spatial_temporal_kolpelke_2017
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | mangal_code | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------:|:-----------------------:|:-----------:|
#' |     57     |   Spatial , Temporal    |      6      |      Host-Parasite      |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source mangal
#' @source https://mangal.io/doc/api/
#' @md
#' @keywords internal
'emln57_spatial_temporal_kolpelke_2017'
