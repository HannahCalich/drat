#'
#' @docType data
#' @title emln72_temporal_ponisio_2017
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | mangal_code | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------:|:-----------------------:|:-----------:|
#' |     72     |        Temporal         |     75      |       Pollination       |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source mangal
#' @source https://mangal.io/doc/api/
#' @md
#' @keywords internal
'emln72_temporal_ponisio_2017'
