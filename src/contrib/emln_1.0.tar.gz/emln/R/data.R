#' View the data sets
#'
#'  @format Data set of multilayer networks
#'
#'  @source {create}
#'
#'  @examples
#'  data(descriptions)
"descriptions"
