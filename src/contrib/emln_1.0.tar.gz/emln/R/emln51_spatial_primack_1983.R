#'
#' @docType data
#' @title emln51_spatial_primack_1983
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------------------:|:-----------:|
#' |     51     |         Spatial         |       Pollination       |    TRUE     |
#' 
#' @format NULL
#' @usage NULL
#' @source Web_of_Life
#' @source http://www.web-of-life.es
#' @md
#' @keywords internal
'emln51_spatial_primack_1983'
