#'
#' @docType data
#' @title emln31_spatial_environment_cornaby_1974
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type  | mangal_code | ecological_network_type | state_nodes |
#' |:----------:|:------------------------:|:-----------:|:-----------------------:|:-----------:|
#' |     31     | Spatial    , Environment |     90      |        Food-Web         |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source mangal
#' @source https://mangal.io/doc/api/
#' @md
#' @keywords internal
'emln31_spatial_environment_cornaby_1974'
