#'
#' @docType data
#' @title emln53_spatial_slovakia
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------------------:|:-----------:|
#' |     53     |         Spatial         |      Host-Parasite      |    FALSE    |
#' 
#' @format NULL
#' @usage NULL
#' @source NA
#' @source NA
#' @md
#' @keywords internal
'emln53_spatial_slovakia'
