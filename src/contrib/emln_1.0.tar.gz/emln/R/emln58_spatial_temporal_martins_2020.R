#'
#' @docType data
#' @title emln58_spatial_temporal_martins_2020
#' 
#' @description Network Description:
#' 
#' | network_id | multilayer_network_type | ecological_network_type | state_nodes |
#' |:----------:|:-----------------------:|:-----------------------:|:-----------:|
#' |     58     |   Spatial , Temporal    |     Plant-Herbivore     |    TRUE     |
#' 
#' @format NULL
#' @usage NULL
#' @source Dryad
#' @source https://doi.org/10.5061/dryad.vmcvdncq0
#' @md
#' @keywords internal
'emln58_spatial_temporal_martins_2020'
